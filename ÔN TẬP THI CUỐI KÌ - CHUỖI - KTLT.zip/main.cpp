#include <iostream>
#include <cstring>
using namespace std;

// a) Đếm Khoảng Trắng 
int ĐemKhoangTrang (const char *s)
{
    int d=0;
    for(int i=0;i<strlen(s);i++)
{
    if(s[i]==' ')
{
    d++;
}
}
    return d;
}

// b) Tìm từ cuối trong chuỗi s

int TimTuCuoi (const char *s)
{
    int n = strlen(s);
    int i= n-1;
    while(i>=0 && s[i]==' ')
    i--;
    int end =i;
    while(i>=0 && s[i]!=' ')
    i--;
    for(int j=i+1;j<=end;j++)
{
    cout<<s[j];
}
    cout<<endl;
}

// c) Đảo ngược chuỗi 
void DaoNguocTu(const char *s) 
{
    char temp[1000]; // Sao chép chuỗi gốc để tránh thay đổi
    strcpy(temp, s);

    char *tu[100];  // Mảng con trỏ lưu các từ
    int n = 0;
    char *p = strtok(temp, " ");  // Tách từ đầu tiên

    while (p != NULL) 
    {
        tu[n++] = p;
        p = strtok(NULL, " "); // Lấy từ tiếp theo
    }

    // In từ theo thứ tự ngược
    for (int i = n - 1; i >= 0; i--) 
    {
        cout << tu[i];
        if (i > 0) cout << " ";
    }
}
int main()
{
    char s[1000];
    cout<<"Nhập vào chuỗi s: ";
    cin.getline(s,1000);
    cout<<"Số lượng khoảng trắng là: "<<ĐemKhoangTrang(s)<<endl;
    cout<<"Từ cuối cùng trong chuỗi s là: "<<TimTuCuoi(s)<<endl;
    cout<<"Chuỗi sau khi đảo ngược từ là: ";
    DaoNguocTu(s);
    return 0;
}